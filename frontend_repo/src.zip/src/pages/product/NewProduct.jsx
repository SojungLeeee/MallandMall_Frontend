import React from "react";

export default function NewProduct() {
  return <div></div>;
}
