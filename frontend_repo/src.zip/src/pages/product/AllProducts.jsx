import React from "react";

export default function AllProducts() {
  return <div></div>;
}
