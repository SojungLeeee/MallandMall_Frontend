import React from "react";

export default function MyCart() {
  return <div></div>;
}
