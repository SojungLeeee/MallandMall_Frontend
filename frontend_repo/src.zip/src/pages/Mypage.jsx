import React from "react";

export default function Mypage() {
  return <div></div>;
}
