import React from "react";

export default function FindId() {
  return <div></div>;
}
