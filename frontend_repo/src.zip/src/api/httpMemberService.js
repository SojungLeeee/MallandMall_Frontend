// httpMemberService.js

import axios from "axios";

const instance = axios.create({
  baseURL: "http://localhost:8090/emart", // Boot 서버에 반드시 CORS 설정 필수
  timeout: 1000,
  headers: { "Content-Type": "application/json" },
});

// 회원가입
export async function fetchSignup(user) {
  console.log("fetchSignup 요청");

  const response = await instance.post(`/signup`, user);

  return response;
}

// 로그인 처리
export async function fetchAuthenticate(authData) {
  const response = await instance.post(`/authenticate`, authData);

  console.log("authenticate.response:", response);

  return response;
}

// 마이페이지 홈
export async function fetchMypage(mypageData) {
  const response = await instance.post(`/mypage/home`, mypageData);

  console.log("authenticate.response:", response);

  return response;
}

// 회원정보 수정
export async function fetchUpdateProfile(userData) {
  const response = await instance.put(`/mypage/memedit`, userData);
  return response;
}

// 회원탈퇴
export async function fetchDeleteAccount(userId) {
  const response = await instance.delete(`/mypage/delete/${userId}`);
  return response;
}
